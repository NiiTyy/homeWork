/*
    TODO: Write program which takes a file and a string by using Standard POSIX functions
    Program counts all the characters in file which the string contains.
    
    For example if the user writes:
    
    ./mycounter x.dat abcd
    
    The program calculates the number of each characters: a, b, c, d in file x.dat
    
    Sample message:
    Number of 'a' characters in 'x.dat' file is: 12
    Number of 'b' characters in 'x.dat' file is: 0
    Number of 'c' characters in 'x.dat' file is: 3
    Number of 'd' characters in 'x.dat' file is: 5
*/
