1. Read all the readme.txt files in question directories for homweork description
2. You can do the questions with your friend. 
3. At most TWO people allowed worked together
4. All of the people have to upload the codes to the UZEM in spite of working together
5. In your programs. Write your name and friend name and also your numbers
6. You must add the add the photograph or scanned version of the paper that includes your name, surname, number and your signature with school id along with your projects 
7. Duration: From: 12th May 2020 Until: 23rd May 2020 at 23:55
