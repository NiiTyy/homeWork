rm mycounter
gcc -o mycounter mycounter.c errorutil.o
cp mycounter ..
