#ifndef ERROR_UTIL_H_
#define ERROR_UTIL_H_

/*Function prototypes*/
void exit_sys(const char *msg);
void exit_fail(const char *msg);

#endif /* ERROR_UTIL_H_ */
