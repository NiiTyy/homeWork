/*
    TODO: WTODO: Refactor mycounterc program by using POSIX functions 
*/
