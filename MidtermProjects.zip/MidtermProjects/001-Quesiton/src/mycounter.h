#ifndef MYCOUNTER_H_
#define MYCOUNTER_H_


#define BUFSIZE     1024

int get_count(char *p, size_t size, char c);
void count_characters(int argc, char **argv, char c);
void run_count_characters_application(int argc, char **argv);


#endif /* MYCOUNTER_H_ */
